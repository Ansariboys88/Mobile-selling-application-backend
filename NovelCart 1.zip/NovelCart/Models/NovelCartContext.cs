﻿using Microsoft.EntityFrameworkCore;
using NovelCart.Configurations;

namespace NovelCart.Models
{
    public partial class NovelCartContext : DbContext
    {
        public NovelCartContext()
        {
        }

        public NovelCartContext(DbContextOptions<NovelCartContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Novel> Novel { get; set; }
        public virtual DbSet<Cart> Cart { get; set; }
        public virtual DbSet<CartItems> CartItems { get; set; }
        public virtual DbSet<Categories> Categories { get; set; }
        public virtual DbSet<CustomerOrderDetails> CustomerOrderDetails { get; set; }
        public virtual DbSet<CustomerOrders> CustomerOrders { get; set; }
        public virtual DbSet<UserMaster> UserMaster { get; set; }
        public virtual DbSet<UserType> UserType { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new CartConfiguration());
            modelBuilder.ApplyConfiguration(new CustomerOrdersConfiguration());
            modelBuilder.ApplyConfiguration(new UserConfiguration());
            modelBuilder.ApplyConfiguration(new NovelConfiguration());

            modelBuilder.Entity<Categories>()
                .HasData(
                    new Categories { CategoryId = 1, CategoryName = "Biography" },
                    new Categories { CategoryId = 2, CategoryName = "Fiction" },
                    new Categories { CategoryId = 3, CategoryName = "Mystery" },
                    new Categories { CategoryId = 4, CategoryName = "Fantasy" },
                    new Categories { CategoryId = 5, CategoryName = "Romance" }
                );

            modelBuilder.Entity<UserType>()
                .HasData(
                    new UserType { UserTypeId = 1, UserTypeName = "Admin" },
                    new UserType { UserTypeId = 2, UserTypeName = "User" }
                );

            modelBuilder.Entity<UserMaster>()
                .HasData(
                    new UserMaster { UserId = 1, FirstName = "Mehul", LastName = "Dekate", Username = "admin", Password = "qwerty", Gender = "Male", UserTypeId = 1 }
                );

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
