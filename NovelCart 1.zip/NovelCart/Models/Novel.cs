﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NovelCart.Models;

public partial class Novel
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int NovelId { get; set; }
    [Required]
    [StringLength(100)]
    public string Title { get; set; }
    [Required]
    [StringLength(100)]
    public string Author { get; set; }
    public int CategoryId { get; set; }
    [Required]
    [Column(TypeName = "smallmoney")]
    public decimal Price { get; set; }
    [StringLength(100)]
    public string? CoverFileName { get; set; }
}
