﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NovelCart.Models
{
    public partial class Cart
    {
        [Key]
        public string CartId { get; set; }
        public int UserId { get; set; }
        [Required]
        public DateTime DateCreated { get; set; }
    }
}