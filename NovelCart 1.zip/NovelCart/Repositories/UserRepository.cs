﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using NovelCart.Dto;
using NovelCart.Interfaces;
using NovelCart.Models;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace NovelCart.DataAccess
{
    public class UserRepository : IUserService
    {
        readonly NovelCartContext _dbContext;
        readonly IConfiguration _config;

        public UserRepository(NovelCartContext dbContext, IConfiguration config)
        {
            _dbContext = dbContext;
            _config = config;

        }

        public async Task<UserDetailsDto> AuthenticateUser(string Username, string Password)
        {
            var userDetails = await _dbContext.UserMaster.FirstOrDefaultAsync(
                u => u.Username == Username && u.Password == Password
                );

            if (userDetails != null)
            {
                UserDetailsDto user = new UserDetailsDto();
                user.UserId = userDetails.UserId;
                user.Username = userDetails.Username;
                user.UserTypeId = userDetails.UserTypeId;
                return user;
            }
            else
            {
                return new UserDetailsDto();
            }
        }

        public async Task<int> RegisterUser(UserMaster userData)
        {
            try
            {
                userData.UserTypeId = 2;
                await _dbContext.UserMaster.AddAsync(userData);
                await _dbContext.SaveChangesAsync();
                return 1;
            }
            catch
            {
                throw;
            }
        }

        public async Task<bool> CheckUserAvailabity(string userName)
        {
            string user = (await _dbContext.UserMaster.FirstOrDefaultAsync(x => x.Username == userName))?.ToString();

            if (user != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<bool> isUserExists(int userId)
        {
            string user = (await _dbContext.UserMaster.FirstOrDefaultAsync(x => x.UserId == userId))?.ToString();

            if (user != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string GenrateToken(UserDetailsDto userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            string role = "User";
            if (userInfo.UserTypeId == 1) { role = "Admin"; }
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, userInfo.Username),
                new Claim("userid", userInfo.UserId.ToString()),
                new Claim(ClaimTypes.Role, role),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
