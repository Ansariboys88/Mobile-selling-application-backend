﻿
namespace NovelCart.Dto
{
    public class UserDetailsDto
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public int UserTypeId { get; set; }
    }
}
